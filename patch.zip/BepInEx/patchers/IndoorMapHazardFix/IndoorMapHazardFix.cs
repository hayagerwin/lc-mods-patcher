using System;
using System.Collections.Generic;
using Mono.Cecil;

namespace IndoorMapHazardFix
{
    public static class Patcher
    {
        public static IEnumerable<string> TargetDLLs
        {
            get
            {
                return new string[] { "Assembly-CSharp.dll" };
            }
        }

        public static void Initialize()
        {
        }

        public static void Patch(ref AssemblyDefinition assembly)
        {
            bool hasIIndoorMapHazard = false;
            bool hasIndoorMapHazard = false;
            bool hasIndoorMapHazardType = false;

            for (int i = 0; i < assembly.MainModule.Types.Count; i++)
            {
                TypeDefinition t = assembly.MainModule.Types[i];
                if (t.Name == "IIndoorMapHazard") hasIIndoorMapHazard = true;
                if (t.Name == "IndoorMapHazard") hasIndoorMapHazard = true;
                if (t.Name == "IndoorMapHazardType") hasIndoorMapHazardType = true;
            }

            if (!hasIIndoorMapHazard)
            {
                TypeDefinition iface = new TypeDefinition(
                    "",
                    "IIndoorMapHazard",
                    TypeAttributes.Public | TypeAttributes.Interface | TypeAttributes.Abstract
                );
                assembly.MainModule.Types.Add(iface);
            }

            if (!hasIndoorMapHazard)
            {
                TypeDefinition cls = new TypeDefinition(
                    "",
                    "IndoorMapHazard",
                    TypeAttributes.Public | TypeAttributes.Class | TypeAttributes.BeforeFieldInit,
                    assembly.MainModule.TypeSystem.Object
                );
                assembly.MainModule.Types.Add(cls);
            }

            if (!hasIndoorMapHazardType)
            {
                TypeDefinition enumType = new TypeDefinition(
                    "",
                    "IndoorMapHazardType",
                    TypeAttributes.Public | TypeAttributes.Class | TypeAttributes.BeforeFieldInit,
                    assembly.MainModule.TypeSystem.Object
                );
                assembly.MainModule.Types.Add(enumType);
            }
        }
    }
}