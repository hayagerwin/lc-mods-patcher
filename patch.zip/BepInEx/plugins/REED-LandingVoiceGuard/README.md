# Landing Voice Guard
Prevents audio/microphone bugs in Lethal Company by managing voice transmission during loading and fixing internal packet buffer overflows.

## Features:
- Automatically mutes outgoing microphone on lever pull during planet descent until doors open.
- Dynamically resizes Dissonance VoIP packet writer buffers (fixes 'Insufficient space in packet writer' crash loops).
- Automatically re-links player voice playback objects and audio mixers.
