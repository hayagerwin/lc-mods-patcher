# Landing Voice Guard
Prevents audio/microphone bugs in Lethal Company by managing voice transmission during loading and fixing internal packet buffer overflows.
