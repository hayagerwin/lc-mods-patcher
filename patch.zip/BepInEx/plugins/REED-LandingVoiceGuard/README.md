# Landing Voice Guard (v2.0.0)

A lightweight engine-level fix for *Lethal Company* that solves VoIP microphone crashes and cutout bugs during moon descents and level transitions.

## 🚀 Key Features

1. **Dissonance PacketWriter Buffer Overflow Fix (v2.0.0)**
   - Resolves the fatal `Insufficient space in packet writer to write ushort` (`ED58BC0A`) error that occurs in modded lobbies (MoreCompany, Mirage, custom moons, etc.).
   - Dynamically expands Dissonance voice transmission packet buffers up to 4096+ bytes on the fly, eliminating the continuous 6,000+ error crash loop that permanently silences microphones.

2. **Automatic Descent & Ascent Voice Guard**
   - Automatically silences outgoing microphone capture during the exact duration of the level loading freeze (from lever pull to door opening).
   - Intercepts Dissonance VoIP getters (`get_IsMuted`, `get_IsTransmitting`) at the engine level.

3. **Touchdown Voice Playback Rebinding**
   - On touchdown (`shipHasLanded`), automatically refreshes and re-links `StartTrackingAllPlayerVoices`, `RefreshPlayerVoicePlaybackObjects`, and `UpdatePlayerVoiceEffects` to ensure all player 3D proximity channels and mixer groups are connected.

## ⚙️ Configuration (`BepInEx/config/com.erwin.landingvoiceguard.cfg`)

- `EnablePacketBufferFix`: `true` (Enabled by default, fixes buffer overflow exceptions).
- `EnableLandingGuard`: `true` (Enabled by default, mutes mic on lever pull until touchdown).
- `EnableTakeoffGuard`: `true` (Enabled by default, mutes mic during takeoff).
- `ShowHudNotice`: `true` (Displays in-game HUD alert during guard state changes).
