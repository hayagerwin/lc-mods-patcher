# Moon Route Buffer
Provides a safe pre-warming buffer window after routing to a new moon, giving slower PCs and HDDs enough time to cache planet assets before the start match lever can be pulled.
